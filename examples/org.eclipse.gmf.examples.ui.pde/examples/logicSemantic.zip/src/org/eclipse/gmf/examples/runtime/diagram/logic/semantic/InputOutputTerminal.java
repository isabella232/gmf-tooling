/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eclipse.gmf.examples.runtime.diagram.logic.semantic;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Input Output Terminal</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.gmf.examples.runtime.diagram.logic.semantic.SemanticPackage#getInputOutputTerminal()
 * @model
 * @generated
 */
public interface InputOutputTerminal extends OutputTerminal, InputTerminal {
} // InputOutputTerminal
